﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class Projectile : MonoBehaviour
{
    public Player player;
    new Rigidbody rigidbody;
    // Accessible in other scripts, but not the editor
    [HideInInspector]
    public Vector3 direction = Vector3.zero;
    [HideInInspector]
    public float speed = 10;
    // Use this for initialization
    void Start ()
    {
        player = FindObjectOfType<Player>();
        rigidbody = GetComponent<Rigidbody>();	
	}
	
	// Update is called once per frame
	void Update ()
    {
        rigidbody.velocity += direction * speed;
    }
}
