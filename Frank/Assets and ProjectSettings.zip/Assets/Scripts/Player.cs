﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class Player : MonoBehaviour {

    public Camera mouseCamera;
    new Rigidbody rigidbody;

    public float acceleration = 3;
    public float turnSpeed = 3;
    public float speed = 2;
    public float fireRate = 0.5f;
    public GameObject projectile;

    public const int facing = 1;
    public const int vert = 2;
    public const int hori = 3;
    public const int diag = 4;
    public const int mouse = 5;
    public const int spread = 6;

    public int shoot = 1;

    // Non editable variables
    float secondsTillFire = 0;
    
    // Use this for initialization
    void Start ()
    {
        rigidbody = GetComponent<Rigidbody>();
	}
	
	// Update is called once per frame
	void Update ()
    {
        // Create a storage variable for input
        Vector3 input = Vector3.zero;

        // Gather the input form the keyboard
        if (Input.GetKey(KeyCode.W))
            input.z = 1;
        if (Input.GetKey(KeyCode.A))
            input.x = -1;
        if (Input.GetKey(KeyCode.S))
            input.z = -1;
        if (Input.GetKey(KeyCode.D))
            input.x = 1;

        // Sets what key to Print
        if (Input.GetKey(KeyCode.Alpha1))
            shoot = facing;
        if (Input.GetKey(KeyCode.Alpha2))
            shoot = vert;
        if (Input.GetKey(KeyCode.Alpha3))
            shoot = hori;
        if (Input.GetKey(KeyCode.Alpha4))
            shoot = diag;
        if (Input.GetKey(KeyCode.Alpha5))
            shoot = mouse;
        if (Input.GetKey(KeyCode.Alpha6))
            shoot = spread;

        // Convert the input to world coordinates
        // So that the player moves in the direction they are facing 
        // instead of on the cardinal world directions (x and z)
        input = transform.TransformDirection(input) * speed;

        // Combine the horizontal input velocity with the vertical velocity we already have
        Vector3 velocity = new Vector3(input.x, rigidbody.velocity.y,input.z);

        // Apply velocity to the player
        rigidbody.velocity = Vector3.Lerp(rigidbody.velocity, velocity, acceleration * Time.deltaTime);
        
        // Disallow the player from getting spun by physics
        rigidbody.maxAngularVelocity = 0;

        // Rotate the player using the mouse input instead of physics
        transform.Rotate(Vector3.up, Input.GetAxis("Mouse X") * turnSpeed);

        // Count down till we can fire
        secondsTillFire -= Time.deltaTime;
        // Check for input and cooldown
        if (Input.GetMouseButton(0) && secondsTillFire <= 0)
        {
            // Reset the cooldown
            secondsTillFire = fireRate;
            switch(shoot)
            {
                case facing:
                    Shoot(transform.position, transform.forward);
                    break;
                case vert:
                    Shoot(transform.position, transform.forward);
                    Shoot(transform.position, -transform.forward);
                    break;
                case hori:
                    Shoot(transform.position, transform.right);
                    Shoot(transform.position, -transform.right);
                    break;
                case diag:
                    Shoot(transform.position, transform.right + transform.forward);
                    Shoot(transform.position, transform.right - transform.forward);
                    Shoot(transform.position, -transform.right + transform.forward);
                    Shoot(transform.position, -transform.right - transform.forward);
                    break;
                case mouse:
                    Vector3 target = Input.mousePosition;
                    target.z = mouseCamera.transform.position.y;
                    target = mouseCamera.ScreenToWorldPoint(target);
                    Shoot(transform.position, (target - transform.position).normalized);
                    break;
                case spread:
                    Shoot(transform.position, transform.forward);
                    Shoot(transform.position, (transform.forward * 7 + transform.right) / 8);
                    Shoot(transform.position, (transform.forward * 7 - transform.right) / 8);
                    break;
            }
        }
    }
    GameObject Shoot(Vector3 pos, Vector3 dir)
    {
        // Find the rotation of the projectile
        Quaternion rot = Quaternion.FromToRotation(Vector3.left, dir);

        // Create the projectile and set its position and rotation
        GameObject created = Instantiate(projectile, pos + dir * 2, rot);

        // Lanch the projectile
        created.GetComponent<Projectile>().direction = dir;

        // Return the lenched projectile
        return gameObject;
    }
}
